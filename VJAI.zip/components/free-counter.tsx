import { Zap } from "lucide-react";
import { useEffect, useState } from "react";

import { MAX_API_LIMIT } from "@/constants";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useProModal } from "@/hooks/use-pro-modal";
import { currentUser } from "@clerk/nextjs";

export const FreeCounter = ({
  apiLimitCount = 0,
}: {
  apiLimitCount: number;
}) => {
  const [mounted, setMounted] = useState(false);
  const proModal = useProModal();

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return null;
  }

  //   if (isPro) {
  //     return null;
  //   }

  return (
    <div className="px-3">
      <Card className="bg-white/10 border-0">
        <CardContent className="py-6">
          <div className="text-center text-sm text-white mb-4 space-y-2">
            <p>
              {" "}
              You had <strong>{apiLimitCount}</strong> Generations So Far...
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
