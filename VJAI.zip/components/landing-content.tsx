"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const students = [
  {
    name: "Avantika Bai",
    avatar: "A",
    title: "20911A05C9",
  },
  {
    name: "Israth Unnisa",
    avatar: "I",
    title: "20911A05E5",
  },
  {
    name: "Shetty Preethi",
    avatar: "S",
    title: "20911A05ZH1",
  },
  {
    name: "R. Nisha",
    avatar: "R",
    title: "21915A0514",
  },
];

export const LandingContent = () => {
  return (
    <div className="px-10 pb-20">
      <h2 className="text-center text-4xl text-white font-extrabold mb-10">
        Developed By
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {students.map((item) => (
          <Card key={item.name} className="bg-[#192339] border-none text-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-x-2">
                <div>
                  <p className="text-lg">{item.name}</p>
                  <p className="text-zinc-400 text-sm">{item.title}</p>
                </div>
              </CardTitle>
              {/* <CardContent className="pt-4 px-0">
                {item.description}
              </CardContent> */}
            </CardHeader>
          </Card>
        ))}
      </div>
    </div>
  );
};
